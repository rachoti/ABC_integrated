export interface ILogin {

    userid: string;
    password: string;
}

