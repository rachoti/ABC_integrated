export class b_Agent{
	public name:string;
	public dob:string;
	public contact:number;
	public address:string;
	public username:string;
	public password:string;
	public aadhar_card:number;
	public pan_card:string;
	public branch_id:string;
	

constructor(name:string, dob:string,contact:number, address:string,username:string, password:string,aadhar_card:number, pan_card:string, branch_id:string)
{

	this.name=name;
	this.dob=dob;
	this.contact=contact;
	this.address=address;
	this.username=username;
	this.password=password;
	this.aadhar_card=aadhar_card;
	this.pan_card=pan_card;
	this.branch_id=branch_id;	
}


}
