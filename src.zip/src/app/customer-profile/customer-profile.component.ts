import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustprofileService } from './custprofile.service';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import {Agent} from '../c_agentmain/c_approve-cust/agent';
@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit {

 getData:any;
  getData1:any;
  id: string; 

  id1:string; 
  constructor(private router: Router,private _httpService:CustprofileService,private _Activatedroute:ActivatedRoute) {

  this.id = localStorage.getItem('token');
   this._httpService.getProfiledetails(this.id).subscribe((res:any[])=>{
     console.log(res);
       this.getData=res;
  
     }); 

 }
 a:Agent;

  ngOnInit() {
      this.id = localStorage.getItem('token');
      this.id1=this._Activatedroute.snapshot.paramMap.get("id"); 
   console.log("fdhder");
   console.log(this.id1);
   this._httpService.getCustdetails(this.id,this.id1).subscribe((res:any)=>{
     console.log(res);
       this.getData1=res;
  
     }); 


  }
  deleteagent()
  {
    for (let prop1 of this.getData) {

   this._httpService.deleteAgents(prop1.empid).subscribe(data=>console.log(data),error=>console.log(error));  
   alert("Account Deleted") 
            
       this.router.navigate(['c_login']);

  }}
  main1()
   {
          this.a=new Agent(this.getData1[0].accno,this.getData1[0].name,this.getData1[0].dob,this.getData1[0].contact,this.getData1[0].address,this.getData1[0].amount,this.getData1[0].branch,this.getData1[0].open_date,this.getData1[0].aadhar_card,this.getData1[0].pan_card,this.getData1[0].acc_type,"Approved");
           this._httpService.UpdateCustomer(this.a,this.getData1[0].accno).subscribe(data=>console.log(data),error=>console.log(error));   
           alert("Customer Approved");
          this.router.navigate(['c_viewcustomer']);

   }
     main2()
   {
          this.a=new Agent(this.getData1[0].accno,this.getData1[0].name,this.getData1[0].dob,this.getData1[0].contact,this.getData1[0].address,this.getData1[0].amount,this.getData1[0].branch,this.getData1[0].open_date,this.getData1[0].aadhar_card,this.getData1[0].pan_card,this.getData1[0].acc_type,"Disapprove");
           this._httpService.UpdateCustomer(this.a,this.getData1[0].accno).subscribe(data=>console.log(data),error=>console.log(error));   
           alert("Customer Disapproved");
          this.router.navigate(['c_viewcustomer']);

   }
 Updated()
 {

    for (let prop1 of this.getData) {

   this._httpService.UpdateAgents(this.id).subscribe(data=>console.log(data),error=>console.log(error));  
  

              
 }


this.router.navigate(['c_agentcomponent']);   

  }

  logout()
  {
    this.router.navigate(['c_login']);
  }
}
