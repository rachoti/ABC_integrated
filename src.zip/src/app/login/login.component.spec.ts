import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { d_LoginComponent } from './login.component';

describe('d_LoginComponent', () => {
  let component: d_LoginComponent;
  let fixture: ComponentFixture<d_LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ d_LoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(d_LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
