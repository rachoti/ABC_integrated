import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import { TranferData } from './Transfer';
@Injectable({
  providedIn: 'root'
})
export class TransferserviceService {

  constructor(private http:HttpClient) { }

  getUserDetails(){
    var cust_id=localStorage.getItem('cust_id');
  	return this.http.get('http://localhost:8090/cust_project/Customer/'+cust_id);
  }
  getTransferDetails(acc1:number,cust:object){
  	return this.http.put('http://localhost:8090/cust_project/Customer/CheckTransfer/'+acc1,cust);
  }
  setUserDetails(amt:number,cust:object){
  	return this.http.put<TranferData>('http://localhost:8090/cust_project/Customer/Transfer/'+amt,cust);
}
}
