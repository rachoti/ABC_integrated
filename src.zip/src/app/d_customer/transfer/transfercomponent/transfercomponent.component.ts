import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfercomponent',
  templateUrl: './transfercomponent.component.html',
  styleUrls: ['./transfercomponent.component.css']
})
export class TransfercomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
