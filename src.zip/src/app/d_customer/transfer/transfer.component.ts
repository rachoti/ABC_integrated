import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {map} from 'rxjs/operators';
import { TransferserviceService } from './transferservice.service';
import { TranferData } from './Transfer';
import {AuthService} from '../../auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {
  customerForm: FormGroup;
  submitted = false;
  accArray = new Array();
  balArray =new Array();
  myArray:Array<TranferData>=new Array();
    mod=new TranferData(0,0,0,0,0,0,0,0,'',0,0);
    getData:any[];
    message:string;
  constructor(private formBuilder: FormBuilder,private router: Router,private _httpService:TransferserviceService,public authService: AuthService) { }

  ngOnInit() {


    //reactive form validation 
    this.customerForm = this.formBuilder.group({
      customer_Acc_no: ['', [Validators.required,Validators.minLength(6)]],
      name: ['', [Validators.required,Validators.minLength(3)]],
      amount1: ['', [Validators.required,Validators.minLength(1)]]
    });


          this._httpService.getUserDetails().subscribe((res:any[])=>{
            var x=JSON.parse(JSON.stringify(res));
            console.log(x);
            for (var i = 0; i < x.length; i++) {
              this.accArray.push(x[i].account_no);
            }
            //this.mod.senderAccount=x[0].account_no;
            console.log(this.accArray);
          
          })

  }

  onChange(deviceValue) {
    for(var j=0;j<this.accArray.length;j++){
      if(this.accArray[j]==deviceValue){
        this.mod.senderAccount=this.accArray[j];
      }
    }
}


  get f() { return this.customerForm.controls; }

        onSubmit() {
          this.submitted = true;
        //  console.log(this.mod);
          // stop here if form is invalid
          if (this.customerForm.invalid) {
              return;
          }else{
            console.log(this.mod);
            this._httpService.getTransferDetails(this.mod.senderAccount,this.mod).subscribe((res:any[])=>{
              var y=JSON.parse(JSON.stringify(res));
              console.log(y);
                this.mod.senderAmt=y.senderAmt;
                this.mod.receiverAmt=y.receiverAmt;
                
                if((y.senderAmt - this.mod.amount1)>y.minBalance){
                  this.mod.receiverAccount=this.mod.customer_Acc_no;
                   this._httpService.setUserDetails(this.mod.amount1,this.mod).subscribe( data => {
                         
                      })
                      this.message="";
                      alert("Succesfully Transfer");
                      //this.mod.customer_Acc_no=0;
                      //this.mod.customer_Acc_no="";
                      
                }else{
                  this.message="";
                  alert("No minimum balance");
                }
            })
            
          }

      }

      logout(): void {
        console.log("Logout");
        this.authService.logout();
        this.router.navigate(['login']);
      }



}
