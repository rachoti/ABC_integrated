export class TranferData{
	account_no: number;
	cust_id: number;
	senderAccount:number;
	customer_Acc_no:number;
	receiverAmt:number;
	senderAmt:number;
	amount1:number;
	tempAmt:number;
	accType:string;
	receiverAccount:number;
	minBalance:number;
	constructor(account_no: number,cust_id: number,senderAccount:number,customer_Acc_no:number,receiverAmt:number,senderAmt:number,amount1:number,tempAmt:number,accType:string,receiverAccount:number,minBalance:number){
		this.cust_id=cust_id;
		this.account_no=account_no;
		this.accType=accType;
		this.amount1=amount1;
		this.minBalance=minBalance;
		this.customer_Acc_no=customer_Acc_no;
		this.senderAccount=senderAccount;
		this.tempAmt=tempAmt;
		this.receiverAccount=receiverAccount;
		this.receiverAmt=receiverAmt;
		this.senderAmt=senderAmt;

	}
}