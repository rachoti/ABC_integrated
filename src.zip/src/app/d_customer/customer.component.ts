import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class d_CustomerComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
profile()
{
	this.router.navigate(['d_profile'])
	
}
loans()
{
  this.router.navigate(['loans'])
}
transfer()
{
  this.router.navigate(['transfer'])
}
balance()
{
  this.router.navigate(['balance'])
}
mini()
{
  this.router.navigate(['mini'])
}
}
