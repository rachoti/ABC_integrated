
import { Component, OnInit } from '@angular/core';
import { DataManager, WebApiAdaptor } from '@syncfusion/ej2-data';
import { Router } from '@angular/router';
import { Transaction } from './Transaction';
import {AuthService} from '../../auth.service';
import { MiniService } from './mini.service';
@Component({
  selector: 'app-mini',
  templateUrl: './mini.component.html',
  styleUrls: ['./mini.component.css']
})
export class MiniComponent implements OnInit {
  accArray = new Array();
  accNo;
  constructor(private router: Router,private _httpService:MiniService,public authService: AuthService) { }
  public data: DataManager;
  public filterSettings: Object;

  ngOnInit() {
    
      this._httpService.getUserDetails().subscribe((res:any[])=>{
      var x=JSON.parse(JSON.stringify(res));
      console.log(x);
      for (var i = 0; i < x.length; i++) {
        this.accArray.push(x[i].account_no);
      }
     // this.mod.senderAccount=x[0].account_no;
      console.log(this.accArray);
    
    })


      var cust_id=localStorage.getItem('cust_id');
      this.accNo=localStorage.getItem('token');
      this.filterSettings = { type: 'Menu' };
      this.data = new DataManager({
        url: 'http://localhost:8090/cust_project/Customer/Transaction/'+this.accNo,
        adaptor: new WebApiAdaptor,
        offline: true
      }); 
      
  }

  onChange(deviceValue) {
    for(var j=0;j<this.accArray.length;j++){
      if(this.accArray[j]==deviceValue){
        this.accNo=this.accArray[j];
        this.data = new DataManager({
          url: 'http://localhost:8090/cust_project/Customer/Transaction/'+this.accNo,
          adaptor: new WebApiAdaptor,
          offline: true
        });
      }
    }
  }

  logout(): void {
    console.log("Logout");
    this.authService.logout();
    this.router.navigate(['login']);
  }

}
