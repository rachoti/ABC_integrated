import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import { Customer } from './Customer';
@Injectable({
  providedIn: 'root'
})
export class ProfileserviceService {

  constructor(private http:HttpClient) { }
  
  getUserDetails(){
    var cust_id=localStorage.getItem('cust_id');
  	return this.http.get('http://localhost:8090/cust_project/Customer/'+cust_id);
  }
  setUserDetails(acc:number,cust:object){
    console.log(cust);
  	return this.http.put<Customer>('http://localhost:8090/cust_project/put/Customer/'+acc,cust);

  }
}
