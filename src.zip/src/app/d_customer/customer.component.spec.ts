import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { d_CustomerComponent } from './customer.component';

describe('d_CustomerComponent', () => {
  let component: d_CustomerComponent;
  let fixture: ComponentFixture<d_CustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ d_CustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(d_CustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
