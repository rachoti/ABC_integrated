export class LoanRequest{
    loan_Acc_no:string;
    open_date:string;
    close_date:string;
    balance:number;
    loan_id:string;
    branch_id:string;
    cust_id:number;
    account_no:number;
    approval:number;
    issue_amount:number;
    constructor(loan_Acc_no:string,open_date:string,close_date:string,balance:number,loan_id:string,branch_id:string,cust_id:number,account_no:number,approval:number,issue_amount:number){
        this.loan_Acc_no=loan_Acc_no;
        this.open_date=open_date;
        this.close_date=close_date;
        this.balance=balance;
        this.loan_id=loan_id;
        this.branch_id=branch_id;
        this.cust_id=cust_id;
        this.account_no=account_no;
        this.approval=approval;
        this.issue_amount=issue_amount;
    }

}