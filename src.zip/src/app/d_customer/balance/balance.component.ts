import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {map} from 'rxjs/operators';
import { BalanceserviceService } from './balanceservice.service';
import { d_Customer } from '../Customer';
import { AuthService } from '../../auth.service';
//import { AuthService } from '../auth.service';

@Component({
  selector: 'app-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.css']
})
export class BalanceComponent implements OnInit {
  // defined the array of data
  public data: string[] = ['Badminton', 'Basketball', 'Cricket', 'Golf', 'Hockey', 'Rugby'];
  // set placeholder text to DropDownList input element
  public placeholder: string = 'Select a game';
  cname;
  accArray = new Array();
  balArray =new Array();
  myArray:Array<d_Customer>=new Array();
  mod=new d_Customer(0,'','',0,'','','',0,'','',0,0);
  getData:any[];
  account_number:string;
  account_number2:string;
  balance2:number;
  balance3:number;
  account_number3:string;
  account_number4:string;
  constructor(private router: Router,private _httpService:BalanceserviceService, public authService: AuthService) { }

  ngOnInit() {
        this.cname=localStorage.getItem('cname');
        console.log(this.cname);
       
  	    this._httpService.getUserDetails().subscribe((res:any[])=>{
        var x=JSON.parse(JSON.stringify(res));
        console.log(x);
        for (var i = 0; i < x.length; i++) {
        	
        	this.accArray.push(x[i].customer_Acc_no);
        	this.balArray.push(x[i].balance);
          
        }
        this.mod.balance=this.balArray[0];
       		
      })
  }
  
  onChange(deviceValue) {
    for(var j=0;j<this.accArray.length;j++){
      if(this.accArray[j]==deviceValue){
        this.mod.balance=this.balArray[j];
      }
    }  
}

  logout(): void {
    console.log("Logout");
    this.authService.logout();
    this.router.navigate(['login']);
  }
  
  
}
