import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SadminloginComponent } from './sadminlogin.component';

describe('SadminloginComponent', () => {
  let component: SadminloginComponent;
  let fixture: ComponentFixture<SadminloginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SadminloginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SadminloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
