
export class Branch{
	
	public br_id:number;
	public br_name:string;
	public br_ifsc: string;
	public br_addr: string;
	public br_contact:number;
	

	
	

	constructor(br_name:string,br_ifsc: string,br_addr: string,br_contact:number)
	{	
		this.br_name= br_name;
		this.br_ifsc= br_ifsc;
		this.br_addr= br_addr;
		this.br_contact = br_contact;
		
	}
}