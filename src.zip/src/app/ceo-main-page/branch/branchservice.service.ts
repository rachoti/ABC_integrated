import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Branch } from './branch';

@Injectable({
  providedIn: 'root'
})
export class BranchserviceService {

  constructor(private http: HttpClient) { }

  createBranches(branch: Object): Observable<Object>{
  	console.log(branch);
    return this.http.post<Branch>('http://localhost:8090/cust_project/post/branch/', branch);
    //return this.http.post<Branch>('http://localhost:8080/A_MyProject/post/branch/', branch);
  }

   getBranchDetails() {
   return this.http.get('http://localhost:8090/cust_project/branch');
    //return this.http.get('http://localhost:8080/A_MyProject/branch');
  }

  delBranch(branch_no){
  	console.log(branch_no);
    return this.http.delete('http://localhost:8090/cust_project/delete/branch/'+ branch_no, branch_no);
    //return this.http.delete('http://localhost:8080/A_MyProject/delete/branch/'+ branch_no, branch_no);
  }

  updateBranch(branch_no : number,branch: Object) {
  	console.log(branch_no);
  	console.log(branch);
    return this.http.put<Branch>('http://localhost:8090/cust_project/put/branch/'+ branch_no, branch);
    //return this.http.put<Branch>('http://localhost:8080/A_MyProject/put/branch/'+ branch_no, branch);
  }
}
