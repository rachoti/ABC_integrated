import { TestBed } from '@angular/core/testing';

import { ViewloanService } from './viewloan.service';

describe('ViewloanService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewloanService = TestBed.get(ViewloanService);
    expect(service).toBeTruthy();
  });
});
