import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ViewloanService } from './viewloan.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AllCommunityModules } from '@ag-grid-community/all-modules';
import { AgGridAngular } from '@ag-grid-community/angular';
import { HttpClient } from '@angular/common/http';
import { Loan } from './loan';
@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {

  getData:any[];
  type: string;
  irate: number;
  desc: string;
  namepattern = "^[A-Za-z]+$";
  private gridApi;
  private gridColumnApi;
  loan: Loan;
  submitted = false;
  model =  new Loan('',0,'');


  constructor(private router: Router,private http: HttpClient,
  private __httpService:ViewloanService,private formBuilder: FormBuilder ) {

    this.__httpService.getLoans()
        .subscribe((res : any[])=>{
            console.log(res);

            this.getData = res;
    });
	}

  columnDefs = [
         
         
         {  headerName: "Loan Id",field: "loan_id",width:100, sortable:true,filter:true , checkboxSelection:true},
         {  headerName: "Loan type",field: "loan_type",width:95,sortable:true,filter:true },
         {  headerName: "Interest Rate",field: "loan_irate",width:110, sortable:true,filter:true },
         {  headerName: "Loan desc",field: "loan_desc",width:150,sortable:true,filter:true},
        
  ];

    rowData: any;

  ngOnInit() {

    this.rowData = this.http.get('http://localhost:8090/cust_project/loan');
  }

  registerForm = this.formBuilder.group({
    ltype: ['', [Validators.required]],
    lrate: ['', [Validators.required]],
    ldesc: ['', [Validators.required] ],
    
    
});

    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
      }
  registerLoan(){
    //this.router.navigate(['/loanregister']);
  
    var check = this.save();
    if(check) {
      
      //this.router.navigate(['ceo-main-page']);
      location.reload();
    }
    else {
      return;
    }

        
  }

  get f() { 
    return this.registerForm.controls; 
  } 

  save(): boolean {
    

      if (this.registerForm.invalid) {
          //alert("INSIDE");
          this.submitted = true;
          //alert("Please enter");
          return false;
      }
      else {
          //alert("ELSE IF");
          this.submitted = false;
          this.type = this.f.ltype.value;
          this.irate = this.f.lrate.value;
          this.desc = this.f.ldesc.value;
          this.loan = new Loan(this.type,this.irate,this.desc);
          this.__httpService.createLoans(this.loan)
            .subscribe(data => console.log(data), error => console.log(error));
          return true;
         
         //this.router.navigate(['a_listadmin']);
        }
  }

    onRemoveSelected() {
        var selectedData = this.gridApi.getSelectedRows();
        console.log(selectedData[0].loan_id);
        this.__httpService.delLoan(selectedData[0].loan_id)
              .subscribe(data => console.log(data), error => console.log(error));

        location.reload();
    }

    updateSelected() {
        var selectedData = this.gridApi.getSelectedRows();
        console.log(selectedData);
        this.model.loan_id = selectedData[0].loan_id;
        this.model.loan_type = selectedData[0].loan_type;
        this.model.loan_irate = selectedData[0].loan_irate;
        this.model.loan_desc = selectedData[0].loan_desc;
    }

    updRow(){
        
        this.loan = new Loan(this.model.loan_type,this.model.loan_irate,this.model.loan_desc);
        this.loan.loan_id = this.model.loan_id;
        
        this.__httpService.updateLoan(this.model.loan_id,this.loan).subscribe(data => console.log(data));
         
         //this.router.navigate(['a_main-page']);  
         location.reload();
    }

    home3(){
  this.router.navigate(['ceo-main-page']);
}

logout(){
  this.router.navigate(['/a_login']);
}

    modules = AllCommunityModules;



  
}
