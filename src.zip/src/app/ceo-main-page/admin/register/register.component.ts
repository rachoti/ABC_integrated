import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Employee } from '../Employee';
import { RegadminService } from './regadmin.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

	name: string;
	dob: string;
	phno: number;
	semail:string;
	
	username :string;
	password : string;
	role :string;
	emprole: "Regional Manager";
	employee : Employee;  
	submitted = false;
	//registerForm: FormGroup;
	namepattern = "^[A-Za-z]+$";

  constructor(private router: Router, private regService : RegadminService,private formBuilder: FormBuilder){

  }

  	registerForm = this.formBuilder.group({
		ename: ['', [Validators.required,Validators.pattern(this.namepattern)]],
		edob: ['', Validators.required],
		ephno: ['', [Validators.required,Validators.pattern(/^[0-9]{10}$/)] ],
		eemail: ['', [Validators.required] ],
		eusername: ['', Validators.required],
		epassword: ['', [Validators.required]]
	});

  	ngOnInit() {
  		this.role = this.emprole;
  	}

    home3(){
  this.router.navigate(['ceo-main-page']);
}

logout(){
  this.router.navigate(['/a_login']);
}
  	get f() { 
		return this.registerForm.controls; 
	} 

	createRegionalManager(){
		var check = this.save();
		if(check) {
			
			this.router.navigate(['admin']);
			//location.reload();
		}
		else {
			return;
		}

		    
	}

	save(): boolean {
		

      	if (this.registerForm.invalid) {
      		//alert("INSIDE");
      		this.submitted = true;
			//alert("Please enter");
			return false;
        }
        else {
        	//alert("ELSE IF");
        	this.submitted = false;
        	this.name = this.f.ename.value;
        	console.log(this.name);

			this.dob = this.f.edob.value;
			this.phno = this.f.ephno.value;
			this.username = this.f.eusername.value;
			this.password = this.f.epassword.value;
			this.role = this.emprole;
			this.semail = this.f.eemail.value;
			this.employee = new Employee(this.name,this.dob,this.phno,this.semail,this.username,this.password,"Regional Manager");
			this.regService.createEmployee(this.employee)
	      		.subscribe(data => console.log(data), error => console.log(error));
	        return true;
      	 
      	 //this.router.navigate(['a_listadmin']);
      	}
	}
}
