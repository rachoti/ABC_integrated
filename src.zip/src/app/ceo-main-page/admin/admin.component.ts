import { Component, OnInit ,ViewChild, AfterViewInit} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Employee } from './Employee';
import { AgGridAngular } from '@ag-grid-community/angular';
import { AllCommunityModules } from '@ag-grid-community/all-modules';
import { AdminserviceService } from './adminservice.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
 title = 'grid-example-app';
    //custArray: Array<employee> = new Array();
    getData:any[];
    openform=false;
   
    private gridApi;
    private gridColumnApi;
   constructor(private router: Router,private http: HttpClient,private __httpService : AdminserviceService,private formBuilder: FormBuilder) {
      
       this.__httpService.getSuperuserDetails()
        .subscribe((res : any[])=>{
            console.log(res);

            this.getData = res;
        });

    }
     



    id : number;
    name: string;
    dob: string;
    phno: number;
    email:string;
    username :string;
    password : string;
    role :string;

    employee : Employee;
    model =  new Employee('','',0,'','','','');
    namepattern = "^[A-Za-z]+$";

    columnDefs = [
         
         
         {  headerName: "DOB",field: "dob",width:100, sortable:true,filter:true , checkboxSelection:true},
         {  headerName: "Emp ID",field: "empId",width:95,sortable:true,filter:true },
         {  headerName: "Role",field: "role",width:110, sortable:true,filter:true },
         {  headerName: "Name",field: "name",width:150,sortable:true,filter:true},
        
         {  headerName: "Contact Number",field: "contact",width:175, sortable:true,filter:true },
         {  headerName: "Username",field: "username",width:175, sortable:true,filter:true },
         {  headerName: "Email",field: "email",width:175, sortable:true,filter:true }
        
        

      ];

    rowData: any;
       registerForm = this.formBuilder.group({
          name: ['', [Validators.required,Validators.pattern(this.namepattern)]],
          dob: ['', Validators.required],
          phno: ['', [Validators.required,Validators.pattern(/^[0-9]{10}$/)] ],
          email: ['', [Validators.required] ],
          username: ['', Validators.required],
          password: ['', [Validators.required]]
        });

       
    ngOnInit() {

         



          this.rowData = this.http.get('http://localhost:8090/cust_project/employee');
         //this.rowData = this.http.get('http://localhost:8080/A_MyProject/employee');
    }

    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
      }

   register(){
     this.router.navigate(['/register']);
   }
   

    

    onRemoveSelected() {
        var selectedData = this.gridApi.getSelectedRows();
        console.log(selectedData[0].empId);
        this.__httpService.delEmployee(selectedData[0].empId)
              .subscribe(data => console.log(data), error => console.log(error));

        location.reload();

        //var id = selectedData
    }

    updateSelected() {
        var selectedData = this.gridApi.getSelectedRows();
        //console.log(selectedData);
        this.id = selectedData[0].empId;
        this.model.empId = selectedData[0].empId;
        this.model.name = selectedData[0].name;
        this.model.dob = selectedData[0].dob;
        this.model.contact = selectedData[0].contact;
        this.model.username = selectedData[0].username;
        this.model.email = selectedData[0].email;
        this.model.pwd = selectedData[0].pwd;

        this.model.role = selectedData[0].role;
       //this.openform=true;
        //return this.openform;
    }

    updRow(){
        //var uData = [];
        //var id = this.updateSelected();
        //new Employee(this.name,this.dob,this.phno,this.email,this.username,this.password,this.role);
        this.employee = new Employee(this.model.name,this.model.dob,this.model.contact,this.model.email,this.model.username,this.model.pwd,this.model.role);
        this.employee.empId = this.model.empId;
        //console.log(this.employee);
        //console.log(id);
        this.__httpService.updateEmployee(this.model.empId,this.employee).subscribe(data => console.log(data));
         
         //this.router.navigate(['a_main-page']);  
         location.reload();
    }

    home3(){
  this.router.navigate(['ceo-main-page']);
}

logout(){
  this.router.navigate(['/a_login']);
}

    
    modules = AllCommunityModules;

}