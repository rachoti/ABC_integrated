package com.slk.model;

public class c_loan {
	public String getLoan_Acc_no() {
		return loan_Acc_no;
	}
	public void setLoan_Acc_no(String loan_Acc_no) {
		this.loan_Acc_no = loan_Acc_no;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public String getOpen_date() {
		return open_date;
	}
	public void setOpen_date(String open_date) {
		this.open_date = open_date;
	}
	public String getApproval() {
		return approval;
	}
	public void setApproval(String approval) {
		this.approval = approval;
	}
	public String getLoan_type() {
		return loan_type;
	}
	public void setLoan_type(String loan_type) {
		this.loan_type = loan_type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getCustoner_Acc_no() {
		return custoner_Acc_no;
	}
	public void setCustoner_Acc_no(long custoner_Acc_no) {
		this.custoner_Acc_no = custoner_Acc_no;
	}
	public String getBranch_name() {
		return branch_name;
	}
	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}
	private String loan_Acc_no;
	private float balance;
	private String open_date;
	private String approval;
	private String loan_type;
	private String name;
	private long custoner_Acc_no;
	private String branch_name;
	

}
